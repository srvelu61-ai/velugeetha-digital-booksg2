# Velugeetha Digital Books

Digital bookstore website for **S. Rathinavelu M.A.** — publishing books in Tamil, English, Malayalam, Kannada, Telugu and Hindi.

## Books Published
1. Special Education for Visually Impaired Students, Teachers & Parents
2. Nature's Pharmacy — Common Sickness and Remedies
3. MindTrap — Hidden Psychology
4. Basic Law Textbook for All
5. Sanathanam vs Dravidian Model
6. Thanthai Periyar

## Files
- `index.html` — Main bookstore page with Razorpay payment buttons
- `delivery_success.html` — Post-payment download page (shown after Razorpay payment)
- `README.md` — This file

## Setup
This site uses GitHub Pages. The main branch automatically serves `index.html`.

## Contact
- WhatsApp: 94443 18208
- Email: velugeethabooks@gmail.com
